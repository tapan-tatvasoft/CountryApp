//
//  LocationManager.swift
//  CountryApp
//
//  Created by Tapan on 16/06/25.
//

import CoreLocation
import Combine

class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    private let locationManager = CLLocationManager()

    @Published var currentCountryCode: String?
    @Published var authorizationStatus: CLAuthorizationStatus = .notDetermined
    var countryName: String?
    
    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        requestPermissionAndLocation()
    }

//    func requestPermission() {
//        locationManager.requestWhenInUseAuthorization()
//    }
    
    func requestPermissionAndLocation() {
       // isLocationLoading = true
        
        switch locationManager.authorizationStatus {
        case .notDetermined:
            // First-time request
            locationManager.requestWhenInUseAuthorization()
            
        case .authorizedWhenInUse, .authorizedAlways:
            // Already authorised — fetch location immediately
            locationManager.requestLocation()
            
        default:
            // Denied / Restricted → fallback
            currentCountryCode = ""
        }
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        authorizationStatus = manager.authorizationStatus

        if authorizationStatus == .authorizedWhenInUse || authorizationStatus == .authorizedAlways {
            locationManager.requestLocation()
        } else {
            currentCountryCode = Locale.current.region?.identifier // fallback to device region
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first else { return }

        let geocoder = CLGeocoder()
        geocoder.reverseGeocodeLocation(location) { [weak self] placemarks, error in
            guard let self = self else { return }
            if let countryName = placemarks?.first?.country {
                self.countryName = countryName
            }
            if let isoCode = placemarks?.first?.isoCountryCode {
                self.currentCountryCode = isoCode
            }
        }
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Location failed: \(error.localizedDescription)")
        currentCountryCode = Locale.current.region?.identifier // fallback
    }
}
