//
//  CountryAppApp.swift
//  CountryApp
//
//  Created by Tapan on 16/06/25.
//

import SwiftUI
import SDWebImageSVGCoder
import SDWebImage

@main
struct CountryAppApp: App {
    @StateObject private var locationManager = LocationManager()
    @StateObject private var viewModel: CountryListViewModel
    
    init() {
        let SVGCoder = SDImageSVGCoder.shared
        SDImageCodersManager.shared.addCoder(SVGCoder)
        let locationManager = LocationManager()
                _locationManager = StateObject(wrappedValue: locationManager)
                _viewModel = StateObject(wrappedValue: CountryListViewModel(apiService: APIManager(), locationManager: locationManager))

    }
    
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                CountryListview(viewModel: viewModel)
            }
        }
    }
}
