//
//  CountryListViewModel.swift
//  CountryApp
//
//  Created by Tapan on 16/06/25.
//

import Foundation
import Combine

@MainActor
class CountryListViewModel: ObservableObject {
    @Published var countries: [Country] = []               // User-added countries
    @Published var searchText: String = ""
    @Published var searchResults: [Country] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String? = nil
    @Published var locationCountryCode: String?

    private var cancellables = Set<AnyCancellable>()
    private let apiService: APIService
    
    init(apiService: APIService = APIManager.shared, locationManager: LocationManager) {
        self.apiService = apiService
        setupSearchBinding()
        locationManager.$currentCountryCode
            .receive(on: DispatchQueue.main)
            .sink { [weak self] code in
                guard let code = code else { return }
                self?.locationCountryCode = code
                self?.selectInitialCountry(with: code, countryName: locationManager.countryName)
            }
            .store(in: &cancellables)
    }
    
    func selectInitialCountry(with code: String, countryName: String?) {
        
        // Check existing countries in database first, if its available then dont do anything
        // else search it from the API and compare country name & country code
       // guard !countries.isEmpty else { return }
        
        Task {
            do {
                try await fetchCountries(countryName: countryName)
                if let matched = searchResults.first(where: { $0.countryCode == code && $0.name.official.contains(countryName ?? "") }) {
                            await MainActor.run {
                                self.countries.append(matched)
                            }
                        }
            }
        }
    }


    private func setupSearchBinding() {
        $searchText
            .debounce(for: .milliseconds(300), scheduler: DispatchQueue.main)
            .removeDuplicates()
            .sink { [weak self] text in
                guard let self = self else { return }
                Task {
                    await self.fetchCountries()
                }
            }
            .store(in: &cancellables)
    }

    func fetchCountries(countryName: String? = nil) async {
        guard !isLoading else { return }
        let nameToSearch = countryName ?? searchText
        guard !nameToSearch.isEmpty else {
            searchResults = []
            return
        }
        isLoading = true
        errorMessage = nil
        do {
            let request = try CouontryListAPI.getCountries(searchName: nameToSearch)
            let countryListResponse = try await apiService.execute(request)
            self.searchResults = countryListResponse
        } catch {
            self.errorMessage = error.localizedDescription
            self.searchResults = []
        }
        isLoading = false
    }

    func addCountry(_ country: Country) {
        guard !countries.contains(where: { $0.id == country.id }),
              countries.count < 5 else { return }
        countries.append(country)
    }

    func removeCountry(at indexSet: IndexSet) {
        countries.remove(atOffsets: indexSet)
    }
}
